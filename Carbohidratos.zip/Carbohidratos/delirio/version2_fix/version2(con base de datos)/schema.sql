-- Recomendado: estructura mínima coherente con el código

CREATE TABLE IF NOT EXISTS `postulaciones` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `cedula` VARCHAR(20) NOT NULL,
  `edad` INT NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `telefono` VARCHAR(20) NOT NULL,
  `situacion` VARCHAR(255) DEFAULT NULL,
  `cantidad_menores` INT DEFAULT 0,
  `prioridad` ENUM('alta','media','baja') NOT NULL DEFAULT 'media',
  `fecha_postulacion` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `estado_postulacion` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `apellido` VARCHAR(100) DEFAULT '',
  `email` VARCHAR(100) NOT NULL,
  `contraseña` VARCHAR(255) NOT NULL,
  `estado` ENUM('pendiente','aceptado','rechazado') NOT NULL DEFAULT 'pendiente',
  `fecha_postulacion` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
