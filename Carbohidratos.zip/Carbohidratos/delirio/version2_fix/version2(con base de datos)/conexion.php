<?php
$host = 'localhost';
$user = 'root';
$pass = ''; // tu contraseña
$db   = 'fourtech';

$conn = new mysqli($host, $user, $pass, $db);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
