<?php
require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre   = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $cedula   = trim($_POST['cedula'] ?? '');
    $edad     = trim($_POST['edad'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $situacion = trim($_POST['situacion'] ?? '');
    $cantidad_menores = trim($_POST['cantidad_menores'] ?? '');
    $prioridadTexto = strtolower(trim($_POST['prioridad'] ?? ''));

    // Normalizar prioridad
    $prioridad = "media";
    if (in_array($prioridadTexto, ["alta", "media", "baja"])) {
        $prioridad = $prioridadTexto;
    }

    // Generar contraseña aleatoria + hash
    $contraseñaGenerada = bin2hex(random_bytes(4));
    $hash = password_hash($contraseñaGenerada, PASSWORD_DEFAULT);

    // --- 1) Insertar en postulaciones ---
    $sql = "INSERT INTO postulaciones 
            (nombre, cedula, edad, email, telefono, situacion, cantidad_menores, prioridad, fecha_postulacion, fecha) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssisssis", $nombre, $cedula, $edad, $email, $telefono, $situacion, $cantidad_menores, $prioridad);
    $stmt->execute();
    $stmt->close();

    // --- 2) Verificar si ya existe en estado_postulacion ---
    $checkSql = "SELECT id FROM estado_postulacion WHERE email = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows === 0) {
        // Si NO existe, lo creo
        $sql2 = "INSERT INTO estado_postulacion 
                 (nombre, apellido, email, contraseña, estado, fecha_postulacion)
                 VALUES (?, ?, ?, ?, 'pendiente', NOW())";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("ssss", $nombre, $apellido, $email, $hash);
        $stmt2->execute();
        $stmt2->close();

        echo "✅ Postulación enviada con éxito.<br>";
        echo "Tu contraseña generada es: <b>" . htmlspecialchars($contraseñaGenerada) . "</b><br>";
        echo "Guárdala para iniciar sesión más adelante.<br>";
    } else {
        echo "✅ Postulación enviada con éxito.<br>";
        echo "Ya existe un registro con este correo en estado_postulacion.<br>";
    }
    $checkStmt->close();

    // --- 3) Guardar respaldo en .txt ---
    $respaldo = "Nombre: $nombre $apellido | Cédula: $cedula | Edad: $edad | Email: $email | Tel: $telefono | Situación: $situacion | Menores: $cantidad_menores | Prioridad: $prioridad | Fecha: " . date("Y-m-d H:i:s") . "\n";
    file_put_contents("respaldo_postulaciones.txt", $respaldo, FILE_APPEND);

    $conn->close();
} else {
    echo "Acceso no válido.";
}
?>
