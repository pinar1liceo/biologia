<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.html");
    exit;
}

include "conexion.php";

$stmt = $conn->prepare("SELECT * FROM estado_postulacion WHERE id=?");
$stmt->bind_param("i", $_SESSION['usuario_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Panel del Usuario</title>
</head>
<body>
    <h2>Bienvenido, <?php echo $user['nombre']." ".$user['apellido']; ?></h2>
    <p>Email: <?php echo $user['email']; ?></p>
    <p>Estado: <?php echo $user['estado']; ?></p>
    <a href="logout.php">Cerrar sesión</a>
</body>
</html>
