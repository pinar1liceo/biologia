<?php
include "conexion.php";

$result = $conn->query("SELECT * FROM estado_postulacion WHERE estado='pendiente'");
?>

<h2>Postulaciones pendientes</h2>
<?php while($row = $result->fetch_assoc()): ?>
    <div>
        <strong><?php echo $row['nombre']." ".$row['apellido']; ?></strong><br>
        Email: <?php echo $row['email']; ?><br>
        <a href="accion.php?id=<?php echo $row['id']; ?>&accion=aceptado">✅ Aprobar</a> | 
        <a href="accion.php?id=<?php echo $row['id']; ?>&accion=rechazado">❌ Rechazar</a>
    </div>
    <hr>
<?php endwhile; ?>
