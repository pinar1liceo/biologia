<?php
session_start();
include "conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT * FROM estado_postulacion WHERE email=? AND estado='aceptado'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['contraseña'])) {
        $_SESSION['usuario_id'] = $user['id'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Usuario no encontrado o pendiente de aprobación.";
        header("Location: login.html?error=" . urlencode($error));
        exit;
    }
}
?>
