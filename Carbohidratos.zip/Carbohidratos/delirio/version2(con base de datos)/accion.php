<?php
include "conexion.php";

if (isset($_GET['id']) && isset($_GET['accion'])) {
    $id = $_GET['id'];
    $accion = $_GET['accion'];

    if ($accion === "aceptado" || $accion === "rechazado") {
        $stmt = $conn->prepare("UPDATE estado_postulacion SET estado=? WHERE id=?");
        $stmt->bind_param("si", $accion, $id);
        $stmt->execute();
        $stmt->close();
    }
}

header("Location: admin.php");
exit;
?>
